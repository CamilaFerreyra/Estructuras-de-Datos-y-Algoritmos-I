#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "PriorityQueue.h"

#define PCOLA_SIZE 10

PCola cola_prioridad_crear() {
  PCola PCola = malloc(sizeof(struct _PCola));
  void** arr = malloc(sizeof(void*) * PCOLA_SIZE);
  PCola->capacidad = 10;
  PCola->ultimo = -1;
  return PCola;
}

int cola_prioridad_es_vacia(PCola pCola) {
  return pCola->ultimo == -1;
}

int comp_key(Elem* a, Elem* b) {
  return a->key - b->key;
}

void* cola_dummy_copy(void* a) {
  return a;
}

void cola_dummy_dest(void* a) {
  (void) a;
  return;
}

void* cola_prioridad_maximo(PCola pCola) {
  //retorna el elemento de maxima prioridad, pero no lo elimina
  if(cola_prioridad_es_vacia(pCola)) {
    printf("No se puede obtener el elemento maximo, ya que la cola esta vacia.");
    return NULL;
  }
  //crear un heap desde array y hacer pop
  BHeap bHeapPCola = bheap_crear_desde_arr(pCola->arr, pCola->ultimo+1, 
    (FuncionComparadora)comp_key,cola_dummy_copy,cola_dummy_dest);
  Elem* elemMax = bheap_pop(bHeapPCola);
  return elemMax->dato;
}

int comp_dato(Elem* a, Elem* b) {
  return strcmp(a->dato, b->dato);
}

void dest_dato(void* dato) {
  free(dato);
  return;
}

void cola_prioridad_eliminar_maximo(PCola pCola) {
  if(cola_prioridad_es_vacia(pCola)) {
    printf("No se puede eliminar el elemento maximo, ya que la cola esta vacia.");
    return;
  }
  Elem* ElemEliminar = cola_prioridad_maximo(pCola);
  for(int i = 0; i <= pCola->ultimo; i++) {
    if(comp_dato(pCola->arr[i], ElemEliminar) == 0) {
      //encontrado
      dest_dato(ElemEliminar->dato);
      free(ElemEliminar);
      //en el lugar del eliminado, pongo el ultimo de la cola
      //que pasa si era el ultimo de la cola?
      if(i < pCola->ultimo) { //ocupo el lugar libre con el ultimo del array
        pCola->arr[i] = pCola->arr[pCola->ultimo--];
      } else { //era el ultimo del array, no lo reemplazo
        pCola->ultimo --;
      }
      return;
    }
  }
}

void cola_prioridad_insertar(PCola PCola, void* dato, int key) {
  //es necesario ver qué pasa cuando la cola esta vacia? 
  //nopi, -1 + 1 = 0.
  Elem* nuevoElem = malloc(sizeof(Elem));
  
  nuevoElem->dato = dato;
  nuevoElem->key = key;
  printf("creado el elemento");

  if(PCola->ultimo + 1 >= PCola->capacidad) {
    //busco más capacidad.
    PCola->arr = realloc(PCola->arr, sizeof(void*)*PCola->capacidad*2);
    PCola->capacidad *= 2;
  }
  printf("\nposicion ultima ac: %d", PCola->ultimo);
  PCola->ultimo++;
  PCola->arr[PCola->ultimo] = (void*)nuevoElem;


  printf("\nposicion ultima dc: %d", PCola->ultimo);

}
